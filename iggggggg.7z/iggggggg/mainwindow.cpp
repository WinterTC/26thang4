#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QTableWidgetItem"
#include "QHeaderView"
#include "QPalette"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent)
{
    setupUi(this);
    QMenu *MenuCL = new QMenu(this);
    Can_Message = new QAction(tr("&CAN message"));
    Lin_Message= new QAction(tr("&LIN message"));
    MenuCL->addAction(Can_Message);
    MenuCL->addSeparator();
    MenuCL->addAction(Lin_Message);
    New->setMenu(MenuCL);

    QMenu *MenuSF = new QMenu(this);
    CAN_error= new QAction(tr("CAN &ErrorFrame"));
    MenuSF->addAction(Can_Message);
    SpecialFrame->setMenu(MenuSF);

    connect(Close,SIGNAL(clicked(bool)),this,SLOT(ButtonClose()));

    TabStandar();
    TabCAN();
}

MainWindow::~MainWindow()
{

}

void MainWindow::ButtonClose()
{
    this->close();
}

void MainWindow::TabStandar()
{
    TabWidgetStandard->setRowCount(7);
    TabWidgetStandard->setColumnCount(15);
    TabWidgetStandard->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);

    QPalette* palette = new QPalette();
    palette->setColor(QPalette::Highlight,Qt::gray);
    TabWidgetStandard->setPalette(*palette);

    TabWidgetStandard->horizontalHeader()->setVisible(false);
    TabWidgetStandard->verticalHeader()->setVisible(false);

    QTableWidgetItem* MessageName = new QTableWidgetItem("Message");
    QTableWidgetItem *MsgParams = new QTableWidgetItem("Msg Params");
    QTableWidgetItem* Triggering = new QTableWidgetItem("Triggering");
    QTableWidgetItem *DataField = new QTableWidgetItem("Data Field");
    QTableWidgetItem *CycleTime = new QTableWidgetItem("Cycle Time [ms]");
    MessageName->setTextAlignment(Qt::AlignCenter);
    MsgParams->setTextAlignment(Qt::AlignCenter);
    Triggering->setTextAlignment(Qt::AlignCenter);
    DataField->setTextAlignment(Qt::AlignCenter);
    CycleTime->setTextAlignment(Qt::AlignCenter);

    //CycleTime->
    //Add Table items here
    TabWidgetStandard->setItem(0,0,MessageName);
    TabWidgetStandard->setSpan(0,0,2,1);
    TabWidgetStandard->setItem(0,1,MsgParams);
    TabWidgetStandard->setSpan(0,1,1,2);
    TabWidgetStandard->setItem(0,3,Triggering);
    TabWidgetStandard->setSpan(0,3,1,4);
    TabWidgetStandard->setItem(0,7,DataField);
    TabWidgetStandard->setSpan(0,7,1,8);
    TabWidgetStandard->setItem(1,1,new QTableWidgetItem ("Channel",QFont::Black));
    TabWidgetStandard->setItem(1,2,new QTableWidgetItem ("DLC"));
    TabWidgetStandard->setItem(1,3,new QTableWidgetItem ("Send"));
    TabWidgetStandard->setItem(1,4,CycleTime);
    TabWidgetStandard->setSpan(1,4,1,3);
    TabWidgetStandard->setItem(1,7,new QTableWidgetItem ("0"));
    TabWidgetStandard->setItem(1,8,new QTableWidgetItem ("1"));
    TabWidgetStandard->setItem(1,9,new QTableWidgetItem ("2"));
    TabWidgetStandard->setItem(1,10,new QTableWidgetItem ("3"));
    TabWidgetStandard->setItem(1,11,new QTableWidgetItem ("4"));
    TabWidgetStandard->setItem(1,12,new QTableWidgetItem ("5"));
    TabWidgetStandard->setItem(1,13,new QTableWidgetItem ("6"));
    TabWidgetStandard->setItem(1,14,new QTableWidgetItem ("7"));

    for(int i=0;i<15;i++){
  if(i>6){
      TabWidgetStandard->setColumnWidth(i,40);
    }
  else{
      TabWidgetStandard->setColumnWidth(i,80);
  }
  if(i==0)TabWidgetStandard->setColumnWidth(i,100);

    }
    //TabWidgetStandard->resizeColumnsToContents();

}

void MainWindow::TabCAN()
{
    TabWidgetCAN->setRowCount(7);
    TabWidgetCAN->setColumnCount(24);
    TabWidgetCAN->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);

    TabWidgetCAN->horizontalHeader()->setVisible(false);
    TabWidgetCAN->verticalHeader()->setVisible(false);

    QTableWidgetItem* MessageName = new QTableWidgetItem("Message Name");
    QTableWidgetItem *MsgParams = new QTableWidgetItem("Message Parameters");
    QTableWidgetItem* Triggering = new QTableWidgetItem("Triggering");
    QTableWidgetItem *DataField = new QTableWidgetItem("Data Field");
    MessageName->setTextAlignment(Qt::AlignCenter);
    MsgParams->setTextAlignment(Qt::AlignCenter);
    Triggering->setTextAlignment(Qt::AlignCenter);
    DataField->setTextAlignment(Qt::AlignCenter);
    //Add Table items here
    TabWidgetCAN->setItem(0,0,MessageName);
    TabWidgetCAN->setSpan(0,0,2,1);
    TabWidgetCAN->setItem(0,1,MsgParams);
    TabWidgetCAN->setSpan(0,1,1,4);
    TabWidgetCAN->setItem(0,5,Triggering);
    TabWidgetCAN->setSpan(0,5,1,11);
    TabWidgetCAN->setItem(0,16,DataField);
    TabWidgetCAN->setSpan(0,16,1,8);
    TabWidgetCAN->setItem(1,1,new QTableWidgetItem ("Identifier",QFont::Black));
    TabWidgetCAN->setItem(1,2,new QTableWidgetItem ("Channel",QFont::Black));
    TabWidgetCAN->setItem(1,3,new QTableWidgetItem ("Frame",QFont::Black));
    TabWidgetCAN->setItem(1,4,new QTableWidgetItem ("DLC"));
    TabWidgetCAN->setItem(1,5,new QTableWidgetItem ("Send"));
    QTableWidgetItem *key = new QTableWidgetItem("Key");
    key->setTextAlignment(Qt::AlignCenter);
    TabWidgetCAN->setItem(1,6,key);
    TabWidgetCAN->setSpan(1,6,1,3);
    QTableWidgetItem *cycleTime = new QTableWidgetItem ("Cycle time [ms]",QFont::Black);
    cycleTime->setTextAlignment(Qt::AlignCenter);
    TabWidgetCAN->setItem(1,9,cycleTime);
    TabWidgetCAN->setSpan(1,9,1,3);
    TabWidgetCAN->setItem(1,12,new QTableWidgetItem ("Burst",QFont::Black));
    TabWidgetCAN->setItem(1,13,new QTableWidgetItem ("Highload"));
    QTableWidgetItem *gateWay=new QTableWidgetItem ("Gateway");

    gateWay->setTextAlignment(Qt::AlignCenter);
    TabWidgetCAN->setItem(1,14,gateWay);
    TabWidgetCAN->setSpan(1,14,1,2);
    TabWidgetCAN->setItem(1,16,new QTableWidgetItem ("0"));
    TabWidgetCAN->setItem(1,17,new QTableWidgetItem ("1"));
    TabWidgetCAN->setItem(1,18,new QTableWidgetItem ("2"));
    TabWidgetCAN->setItem(1,19,new QTableWidgetItem ("3"));
    TabWidgetCAN->setItem(1,20,new QTableWidgetItem ("4"));
    TabWidgetCAN->setItem(1,21,new QTableWidgetItem ("5"));
    TabWidgetCAN->setItem(1,22,new QTableWidgetItem ("6"));
    TabWidgetCAN->setItem(1,23,new QTableWidgetItem ("7"));

    for(int i=0;i<24;i++){
        if(i==0){
            TabWidgetCAN->setColumnWidth(i,80);
        }
        else if(i<16){
            TabWidgetCAN->setColumnWidth(i,60);
        }
        else{
        TabWidgetCAN->setColumnWidth(i,30);}
    }

}
