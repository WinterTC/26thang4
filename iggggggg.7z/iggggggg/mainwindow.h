#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ui_mainwindow.h"
#include "QMenu"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow,Ui_MainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
private slots:
    void ButtonClose();
    void TabStandar();
    void TabCAN();

private:
   //QMenu *News;
   QAction *Can_Message;
   QAction *Lin_Message;
   QAction *CAN_error;

};

#endif // MAINWINDOW_H
